import React from 'react'

function Banner({classNames, classNames1}) {
  return (
    <nav className={`bg-[#0E0E52] py-2 h-fit overflow-y-auto ${classNames}`}>
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="flex justify-center ">
      <div className="flex-shrink-0 flex items-center">
        <a href="#" className={` md:text-[50px] text-[21px] md:py-0 py-5 font-bold tracking-wider ${classNames1 ?classNames1:"text-white"} capitalize`}>Bronx Hernia Specialists</a>
      </div>

      {/* <div className="flex-shrink-0 flex items-center">
        <a href="#" className="text-white text-3xl font-bold tracking-wider">{name}</a>
      </div> */}

      {/* <div className="flex items-center sm:hidden">
        <button className="text-white hover:text-gray-400 focus:outline-none focus:text-gray-400" aria-label="Toggle menu">
          <svg className="h-6 w-6 fill-current" viewBox="0 0 24 24">
            <path v-if="!open" fill-rule="evenodd" clip-rule="evenodd" d="M4 6h16v2H4V6zm0 5h16v2H4v-2zm0 5h16v2H4v-2z"/>
            <path v-if="open" fill-rule="evenodd" clip-rule="evenodd" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>
      </div> */}

      {/* <div className="hidden sm:flex sm:items-center sm:ml-6">
        <a href="#" className="text-white hover:text-gray-400 px-3 py-2 rounded-md text-sm font-medium">Home</a>
        <a href="#" className="text-white hover:text-gray-400 px-3 py-2 rounded-md text-sm font-medium">About</a>
        <a href="#" className="text-white hover:text-gray-400 px-3 py-2 rounded-md text-sm font-medium">Contact</a>
      </div> */}
    </div>
  </div>

  {/* <div className="hidden sm:hidden">
    <div className="px-2 pt-2 pb-3">
      <a href="#" className="text-white hover:text-gray-400 block px-3 py-2 rounded-md text-base font-medium">Home</a>
      <a href="#" className="text-white hover:text-gray-400 block px-3 py-2 rounded-md text-base font-medium">About</a>
      <a href="#" className="text-white hover:text-gray-400 block px-3 py-2 rounded-md text-base font-medium">Contact</a>
    </div>
  </div> */}
</nav>

  )
}

export default Banner
