import React from "react";

function ReviewSection({children}) {
  return (
    <div className="grid md:grid-cols-2 grid-cols-1 md:gap-10 md:flex-row h-contain w-fit mt-[5px] md:mr-10 md:ml-10 ">
      {children}
    </div>
  );
}

export default ReviewSection;
