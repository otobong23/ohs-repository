import React from "react";
// import doctorImage from "./doctor.jpg";

const FormSection = () => {
  return (
    <>
    <div className="grid md:grid-cols-2 grid-cols-1 md:flex-row md:h-fit h-fit w-screen">
      <div className=" p-5 m-auto">
        <div className=" md:px-8 rounded-lg">
          <h1 className="text-3xl md:text-4xl font-bold mb-10 text-[#449DD1] capitalize">Get in touch</h1>
          <form className="space-y-4">
            <div className="my-5">
              <label htmlFor="name" className="block font-medium">
                Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                className="block w-full h-[45px] px-10 rounded-md border-gray-300 border  shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              />
            </div>
            <div className="grid grid-cols-2 my-5">
              <div className="pr-3">
                <label htmlFor="email" className="block font-medium">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="block w-full h-[45px] px-5 rounded-md border-gray-300 border shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block font-medium">
                  Phone
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  className="block w-full h-[45px] px-5 rounded-md border-gray-300 border shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                />
              </div>
            </div>
            <div className="my-5">
              <label htmlFor="reason" className="block font-medium">
                Reason for contact:
              </label>
              <select
                id="reason"
                name="reason"
                className="block w-full h-[45px] px-5 rounded-md border-gray-300 border shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              >
                <option value="">Select a reason</option>
                <option value="Surgery Appointment">Surgery Appointment</option>
                <option value="In-Office Appointment">In-Office Appointment</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <button
                type="submit"
                className="px-4 py-4 bg-[#0E0E52] text-white rounded-md w-full mt-7"
              >
                SUBMIT
              </button>
            </div>
          </form>
        </div>
      </div>
      <div className=" p-4 my-5 mr-5 py-3 border-2 border-gray-100">
        <h2 className="font-bold text-3xl pb-2 text-left pt-5 pb-5 text-[#449DD1] capitalize">
        Do You Need A Hernia Specialist?
        </h2>
        <div className="py-2">
          <h4 className="font-bold text-2xl capitalize">Inguinal Hernia</h4>
          <p>
            Inguinal hernias are the most common type of hernia encountered.
            They occur in women but occur more commonly in males. About 1 in 4
            males will have an inguinal hernia at some point in their lifetime.
            The testicle descending from the abdomen into the scrotum
            predisposes males to have a natural weakness in the groin where
            inguinal hernias occur.
          </p>
          <p>I employs a tackless technique for laparoscopic inguinal hernia repair, thereby minimizing immediate post-operative pain as well as the chances of chronic pain.</p>
        </div>
        <div className="py-3">
          <h4 className="font-bold text-2xl capitalize">Haital Hernia</h4>
          <p>
            Hiatal hernias typically occur later in life and cause a myriad of
            symptoms. Symptoms may include heartburn, nausea, vomiting,
            regurgitation, abdominal pain, chest pain, difficulty swallowing,
            bloating, belching, or coughing. The term hiatal comes from hiatus
            (or opening), specifically the esophageal hiatus.
          </p>
        </div>
        {/* <div className="py-1">
          <h4 className="font-bold text-1xl">Umbilical Hernia</h4>
          <p>
            Umbilical hernias are one of the most common hernias encountered.
            They are naturally occurring hernias, common in all ages from
            infants to the elderly. They occur at the navel, also known as the
            umbilicus. This is the site that the umbilical cord previously
            passed through and acts as a natural site of weakness in the
            abdominal wall.
          </p>
        </div> */}
      </div>
    </div>
  </>
  );
};

export default FormSection;
