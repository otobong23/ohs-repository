import React from "react";

function VideoSection() {
  return (
    <div>
      <div className="grid md:grid-cols-2 grid-cols-1 md:flex-row md:h-fit w-fit md:mr-10 md:ml-10">
        <div className=" p-4 md:my-5 md:py-3 ">
          {/* <h2 className="font-bold text-3xl pb-2 text-center md:pt-10 md:pb-10">
        HERNIA SURGEON TESTIMONIALS (❌)
        </h2> */}
          <div className="py-1">
            <h4 className="font-bold text-2xl capitalize">Umbilical Hernia</h4>
            <p>
              Umbilical hernias are one of the most common hernias encountered.
              They are naturally occurring hernias, common in all ages from
              infants to the elderly. They occur at the navel, also known as the
              umbilicus. This is the site that the umbilical cord previously
              passed through and acts as a natural site of weakness in the
              abdominal wall.
            </p>
            <p className="pt-3">
              Umbilical hernias present with a painless bulge at the navel, that
              may become larger and more painful with time. They are usually
              more symptomatic with activity or prolonged standing and require
              an experienced hernia surgeon for a successful outcome.
            </p>
          </div>
        </div>
        <div className="md:m-auto">
          <div className="md:pr-8 rounded-lg">
            <iframe
              className="md:h-[320px] md:w-[590px] w-screen h-[50vh]"
              src="https://www.youtube.com/embed/glkhWjzjCHM"
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  );
}

export default VideoSection;
