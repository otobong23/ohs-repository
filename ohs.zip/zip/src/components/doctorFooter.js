import React from "react";

function Footer() {
  return (
    <>
      {/* <footer className="bg-[#0E0E52] h-fit w-screen md:px-10 py-5">
        <div className=''>

        </div>
      </footer> */}
      {/* <footer className="bg-gray-900 py-8">
  <div className="container mx-auto">
    <div className="flex flex-wrap">
      <div className="w-full lg:w-1/3 px-4">
        <h2 className="text-lg font-semibold text-white mb-4">Row 1</h2>
        <nav className="list-none mb-10">
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 1</a>
          </li>
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 2</a>
          </li>
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 3</a>
          </li>
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 4</a>
          </li>
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 5</a>
          </li>
        </nav>
      </div>
      <div className="w-full lg:w-1/3 px-4">
        <div className="flex items-center justify-center">
          <span className="text-white font-semibold text-xl">XHS</span>
        </div>
      </div>
      <div className="w-full lg:w-1/3 px-4">
        <h2 className="text-lg font-semibold text-white mb-4">Row 2</h2>
        <nav className="list-none mb-10">
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 6</a>
          </li>
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 7</a>
          </li>
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 8</a>
          </li>
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 9</a>
          </li>
          <li>
            <a href="#" className="text-gray-400 hover:text-white">Link 10</a>
          </li>
        </nav>
      </div>
      
    </div>
  </div>
</footer> */}
      <footer className="bg-[#0E0E52] text-gray-400 md:px-40 m-auto p-auto text-center flex flex-col justify-center">
        <div className="flex flex-col md:mt-5 items-center mb-4 text-white text-2xl md:hidden block">
          {/* <img src="/logo.png" alt="XHS Logo" className="h-8" /> */}
          <h1 className="pt-4">BRONX HERNIA SPECIALISTS</h1>
        </div>
        <div className="container mx-auto md:py-8 py-2 px-4 flex flex-wrap md:justify-between justify-center">
          <div className="flex flex-wrap text-center space-y-2 mb-4 flex-col mr-8">
            <a href="#" className="md:mr-6">
              Hernia
            </a>
            <a href="#" className="md:mr-6">
              Inguinal Hernia
            </a>
            <a href="#" className="md:mr-6">
              Hiatal Hernia
            </a>
            <a href="#" className="md:mr-6">
              Ventral Hernia
            </a>
            <a href="#" className="md:mr-6">
              Epigastric Hernia
            </a>
          </div>
          <div className="flex flex-col md:mt-5 items-center mb-4 text-white text-4xl hidden md:block">
            {/* <img src="/logo.png" alt="XHS Logo" className="h-8" /> */}
            <h1 className="text-5xl">BRONX HERNIA</h1>
            {/* <h1>HERNIA</h1> */}
            <h1 className="text-6xl">SPECIALISTS</h1>
          </div>
          <div className="flex flex-wrap text-center flex-col mb-4 ml-8 space-y-2 mb-4 flex-col mr-8">
            {/* <div className="flex-grow"></div> */}
            <a href="#" className="md:mr-6">
              Umbilical Hernia
            </a>
            <a href="#" className="md:mr-6">
              Perineal hernia
            </a>
            <a href="#" className="md:mr-6">
              Femoral hernia
            </a>
            <a href="#" className="md:mr-6">
              incisional hernia
            </a>
            <a href="#" className="md:mr-6">
              Spigelian hernia
            </a>
          </div>
        </div>
      </footer>
      <div className="h-fit px-4 py-[10px] bg-white text-[12px]">
        <p>
          <b>Disclaimer:</b>We are a medical marketing entity. We are not
          considered a medical practice, institution or hospital. Please know
          that email communication via our website may not be done through a
          secure platform. Although it is unlikely, there is a possibility that
          information you include in your submission can be intercepted and read
          by parties other than the intended recipient. To protect your
          confidential information, please do not include personal identifying
          information such as your birth date or personal medical information in
          any emails or website submissions you send to us.
        </p>
        {/* <p>Disclaimer: Patient pictures on this site are models, and the names were changed to protect patient identities.
Patient results and recovery will vary depending on disease severity, and may be different than those quoted in testimonials.</p>
            </div> */}
      </div>
    </>
  );
}

export default Footer;
