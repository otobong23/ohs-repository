import React from "react";

function Content() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2">
      <div className="h-fit overflow-y-auto w-fit p-5 md:px-5 m-5 border-4">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-[#449DD1] capitalize">
        How do I know if my hernia needs surgery?
        </h1>
        <div className="relative">
          <p className="  ">
          A hernia is a common but frequently misunderstood condition. You may have a hernia if you have swelling and a bulge that is able to be “pushed back” into your abdomen. If it continues to grow, you will need to have hernia surgery in order to repair it.
          </p>
        </div>
      </div>


      <div className="h-fit overflow-y-auto w-fit p-5 md:px-5 m-5 border-4 md:py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-[#449DD1] capitalize">
        How long does a hernia operation take?
        </h1>
        <div className="relative">
          <p className="  ">
          The operation usually takes about 30 to 45 minutes to complete and you'll usually be able to go home on the same day. Some people stay in hospital overnight if they have other medical problems or live on their own.
          </p>
        </div>
      </div>

    </div>
  );
}

export default Content;
