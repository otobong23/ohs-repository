import React from "react";
// import doctorImage from "./doctor.jpg";

const Header = ({children, header1, classNames}) => {
  return (
    <div className="grid md:grid-cols-2 md:flex-row h-fit w-screen">
      <div className="py-5 m-auto pl-3">
        <h1 className={`text-[60px] font-bold mb-4 leading-none text-[#449DD1]	${classNames} capitalize`}>
          {header1}
        </h1>
        <div className="grid grid-cols-2 md:gap-10">
          <ul className="list-disc pl-5 space-y-2">
            <li>Inguinal hernia</li>
            <li>Incisional hernia</li>
            <li>Hiatal hernia</li>
            <li>Femoral hernia</li>
            <li>Ventral hernia</li>
          </ul>
          <ul className="list-disc md:pl-5 space-y-2">
            <li>Umbilical hernia</li>
            <li>Recurrent hernia</li>
            <li>Diaphragmatic hernia</li>
            <li>Spigelian hernia</li>
            <li>Flank hernia</li>
          </ul>
        </div>
      </div>
      <div className="p-1 my-4 py-3 border-8 border-gray-100 m-2">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:m-auto md:py-[1px] md:px-5">
            <div className="md:h-fit ">
            {children}

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
