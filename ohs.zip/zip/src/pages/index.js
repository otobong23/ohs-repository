import Head from "next/head";
import Image from "next/image";
import { Inter } from "@next/font/google";
import styles from "@/styles/Home.module.css";
import Navbar from "@/components/navbar";
import Header from "@/components/header";
import Banner from "@/components/banner";
import FormSection from "@/components/formSection";
import VideoSection from "@/components/videoSection";
import ReviewSection from "@/components/reviewSection";
import Footer from "@/components/Footer";
import Content from "@/components/content";

const inter = Inter({ subsets: ["latin"] });

export default function Home() {
  return (
    <>
      <Head>
        <title>OHS</title>
        <meta
          name="description"
          content="Looking for the best Bronx hernia surgeons? Look no further than our team of experienced and highly skilled surgeons. We specialize in the diagnosis, treatment, and repair of all types of hernias, from inguinal and femoral hernias to umbilical and incisional hernias.
"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="true"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100;200;300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        ></link>
      </Head>
      <Navbar name="" />
      <Header header1={`Hernia Surgery`}>
        <h1 className="text-3xl md:text-4xl font-bold mb-4 text-[#449DD1] capitalize">
          How risky is a hernia?
        </h1>
        <div className="relative">
          <p className="">
            An incarcerated hernia can cut off blood flow to part of your
            intestine. Strangulation can lead to the death of the affected bowel
            tissue. A strangulated hernia is life-threatening and requires
            immediate surgery.
          </p>
          <p className="pt-5">
            Symptoms of a strangulated hernia can include severe pain, nausea,
            vomiting, and fever. In some cases, a hernia can be gently pushed
            back into place, but a strangulated hernia requires surgery to
            repair.{" "}
          </p>
        </div>
      </Header>
      <Banner
        name=""
        classNames={`grad text-[#0E0E52]`}
        classNames1={`text-[#0E0E52]`}
      />
      <FormSection />
      <VideoSection />
      <Banner
        name=""
        classNames={`grad text-[#0E0E52]`}
        classNames1={`text-[#0E0E52]`}
      />
      <Content />
      <Footer />
    </>
  );
}
