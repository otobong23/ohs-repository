import Head from "next/head";
import Image from "next/image";
import { Inter } from "@next/font/google";
import styles from "@/styles/Home.module.css";
import Navbar from "@/components/navbar";
import Header from "@/components/header";
import Banner from "@/components/banner";
import FormSection from "@/components/formSection";
import VideoSection from "@/components/videoSection";
import ReviewSection from "@/components/reviewSection";
import Footer from "@/components/Footer";
import DocImmg from "@/assets/christopherolukoga.jpg";
// import FiveStarDoctorReviewCard from "./reviewCard";
// import ReviewCard from "./reviewCard";
import StarIcon from "@mui/icons-material/Star";
import LocalHospitalIcon from "@mui/icons-material/LocalHospital";
import AddLocationIcon from "@mui/icons-material/AddLocation";
import DoctorFooter from "@/components/doctorFooter";

const inter = Inter({ subsets: ["latin"] });

export default function DoctorPage() {
  return (
    <>
      <Head>
        <title>Orlando Hernia Specialists | Femoral hernia Procedures</title>
        <meta
          name="description"
          content="Looking for the best Orlando hernia surgeons? Look no further than our team of experienced and highly skilled surgeons. We specialize in the diagnosis, treatment, and repair of all types of hernias, from inguinal and femoral hernias to umbilical and incisional hernias.
"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="true"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100;200;300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        ></link>
      </Head>
      <Navbar name={"Dr. Christopher Olukoga"} />
      <Header
        header1={`Femoral hernia Procedures`}
        classNames={`md:pb-5 pb-0 md:text-[60px] text-[39px]`}
      >
        <h1 className="text-2xl md:text-4xl font-bold mb-4 text-[#449DD1]">
          Christopher Olukoga, MD
        </h1>
        <div className="relative">
          <Image
            src={DocImmg}
            alt="Doctors passport"
            className="float-left w-48 md:mr-5 mr-2 h-auto"
          />
          <p className="text-1xl ">
            Dr. Christopher Olukoga, MD is a general surgery specialist in Winter Park, FL.
            He is affiliated with medical facilities AdventHealth Winter Park and Adventhealth Orlando.
            His office accepts new patients.
          </p>
        </div>
        {/* <br />
        <div className="block">
          <div>
            <div className="">
              <b>Contact:</b> 1(512) 467-7151
            </div>
          </div>
        </div>
        <div className="">
          <b>Address:</b> 3901 Medical Parkway, Suite 200 Miami, TX 78756
        </div> */}
      </Header>
      <Banner
        classNames={`grad text-[#0E0E52]`}
        classNames1={`text-[#0E0E52]`}
      />

      <FormSection />

      <VideoSection />

      <Banner
        classNames={`grad text-[#0E0E52]`}
        classNames1={`text-[#0E0E52]`}
      />
      <ReviewSection>
        <div className="w-fit m-auto text-center">
          <h4 className="text-bold text-3xl text-[#449DD1]">Specialties</h4>
          <div className="grid grid-cols-4 divide-x md:p-4 my-1 ">
            <div className="text-center py-5">
              <LocalHospitalIcon
                className="border rounded-full h-10 w-10 p-2 text-[60px] text-4xl"
                fontSize="300px"
              />
              <p style={{ fontSize: "10px" }}>Hernia</p>
            </div>
            <div className="text-center py-5">
              <LocalHospitalIcon
                className="border rounded-full h-10 w-10 p-2 text-[60px] text-4xl"
                fontSize="300px"
              />
              <p style={{ fontSize: "10px" }}>Ileus</p>
            </div>
            <div className="text-center py-5">
              <LocalHospitalIcon
                className="border rounded-full h-10 w-10 p-2 text-[60px] text-4xl"
                fontSize="300px"
              />
              <p style={{ fontSize: "10px" }}>Intestinal Obstruction</p>
            </div>
            <div className="text-center py-5">
              <LocalHospitalIcon
                className="border rounded-full h-10 w-10 p-2 text-[60px] text-4xl"
                fontSize="300px"
              />
              <p style={{ fontSize: "10px" }}>Cholecystitis and Gallstones</p>
            </div>
          </div>
          <div className="grid grid-cols-4 divide-x  md:p-4 my-1  text-center m-auto">
            <div className="text-center py-5 ">
              <LocalHospitalIcon
                className="border rounded-full h-10 w-10 p-2 text-[60px] text-4xl"
                fontSize="300px"
              />
              <p style={{ fontSize: "10px" }}>Thoracic</p>
            </div>
            <div className="text-center py-5 md:px-10">
              <LocalHospitalIcon
                className="border rounded-full h-10 w-10 p-2 text-[60px] text-4xl"
                fontSize="300px"
              />
              <p style={{ fontSize: "10px" }}>Laparoscopy</p>
            </div>
            <div className="text-center py-5">
              <LocalHospitalIcon
                className="border rounded-full h-10 w-10 p-2 text-[60px] text-4xl"
                fontSize="300px"
              />
              <p style={{ fontSize: "10px" }}>Thyroid</p>
            </div>
            <div className="text-center py-5">
              <LocalHospitalIcon
                className="border rounded-full h-10 w-10 p-2 text-[60px] text-4xl"
                fontSize="300px"
              />
              <p style={{ fontSize: "10px" }}>General Surgery</p>
            </div>
          </div>
        </div>
        <div className=" px-4 md:my-5  m-auto">
          <div className="w-fit md:px-8 p-3 border m-auto">
            <div className="flex justify-center">
              <StarIcon color="yellow" style={{ color: "#F4E87C" }} />
              <StarIcon color="yellow" style={{ color: "#F4E87C" }} />
              <StarIcon color="yellow" style={{ color: "#F4E87C" }} />
              <StarIcon color="yellow" style={{ color: "#F4E87C" }} />
              <StarIcon color="yellow" style={{ color: "#F4E87C" }} />
            </div>
            <b>Dan L.</b>
            <p>
              {" "}
              <b className="text-2xl">"</b>I researched hernia surgeons intently after having two failed surgeries in 2021. I had one more shot to get this right and I would not take recommendations from family or friends any longer, I wanted the best. After exhaustive searches on the internet, I found Dr. Olukoga. I read his reviews and they were impressive. I decided that a visit was my next course of action. When he walked into the exam room, I felt an overwhelming feeling of composure and tranquility. My previous surgeon stated that if my second robotic surgery was not successful, the next time they would have to "open me up", the thought of that terrified me. After my initial examination with Dr. Olukoga, he said he believed he could do the surgery robotically but could not be 100% sure until he got into the operating room. My surgery took 8-1/2 hours, mostly because he was cleaning up the mess from the previous surgeon. After the surgery, no pain and 30 days later, still no pain! This surgeon is REMARKABLE!!!{" "}
              <b className="text-2xl">"</b>
            </p>
            <b className="flex justify-right py-5">
              <AddLocationIcon />

            </b>
          </div>
        </div>
      </ReviewSection>
      <DoctorFooter />
    </>
  );
}
